# Icy Apotheosis Boss (icy_apotheosis)

神化(Apotheosis)附属mod，允许指定任意实体固定成为神化Boss，并可配置Boss的稀有度等级。

## 功能特性

- **固定Boss**: 指定任意实体，生成时自动转换为神化Boss
- **可配置稀有度**: 支持 common, uncommon, rare, epic, mythic, ancient 六种稀有度
- **小Boss模式**: 指定实体成为神化小Boss
- **自定义属性**: 根据稀有度自动调整生命值、速度、伤害、护甲等属性
- **游戏内命令**: 支持在游戏内重载配置和查看已配置的实体列表

## 依赖

- Minecraft 1.20.1
- Forge 47.1.0+
- Apotheosis 1.20.1-7.4.8+ (必需)

## 配置说明

配置文件位于 `config/icy_apotheosis.toml`。

### Boss实体列表

格式: `实体ID|稀有度等级`

```toml
bossEntities = [
    "minecraft:ender_dragon|mythic",
    "minecraft:wither|epic",
    "minecraft:warden|mythic",
    "minecraft:zombie|rare"
]
```

### 小Boss实体列表

```toml
minibossEntities = [
    "minecraft:vindicator|rare",
    "minecraft:witch|rare",
    "minecraft:illusioner|epic"
]
```

### 其他配置

```toml
# 是否在Boss生成时发送公告
announceBoss = true

# Boss生成后是否自动锁定玩家
bossAutoAggro = true
```

## 稀有度等级说明

| 稀有度 | 生命值加成 | 速度加成 | 伤害加成 | 护甲加成 | 效果 |
|--------|-----------|---------|---------|---------|------|
| common | +20 | 0% | 0% | 0 | 无 |
| uncommon | +40 | +10% | +20% | +2 | 无 |
| rare | +60 | +15% | +30% | +4 | 速度I-II |
| epic | +100 | +20% | +50% | +5 | 速度II-IV, 再生I-III |
| mythic | +140 | +30% | +70% | +6 | 速度II-IV, 再生II-IV, 抗性I-II |
| ancient | +200 | +40% | +100% | +8 | 速度III-VI, 再生III-VI, 抗性II-IV, 隐身 |

## 游戏内命令

- `/icyapotheosis reload` - 重新加载配置文件
- `/icyapotheosis list` - 显示已配置的实体列表
- `/icyapotheosis help` - 显示帮助信息

## 项目结构

```
icy_apotheosis/
├── build.gradle              # 构建配置
├── gradle.properties         # 项目属性
├── settings.gradle           # Gradle设置
├── src/main/
│   ├── java/com/icyapotheosis/
│   │   ├── IcyApotheosis.java      # Mod主类
│   │   ├── IcyApotheosisConfig.java # 配置管理
│   │   ├── BossHandler.java        # Boss转换处理
│   │   └── ModCommands.java        # 游戏内命令
│   └── resources/
│       ├── META-INF/mods.toml      # Mod元数据
│       ├── pack.mcmeta             # 数据包配置
│       ├── config/icy_apotheosis-defaults.toml # 默认配置示例
│       └── assets/icy_apotheosis/
│           └── lang/
│               ├── zh_cn.json      # 中文语言文件
│               └── en_us.json      # 英文语言文件
```

## 开发说明

### 构建

```bash
./gradlew build
```

### 运行开发环境

```bash
./gradlew runClient
```

## License

MIT
